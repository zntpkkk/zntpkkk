package mines.mines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReplicaMinesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReplicaMinesApplication.class, args);
	}
}
