// GhostPay API Integration
export interface GhostPayConfig {
  apiKey: string
  apiUrl: string
  webhookSecret: string
}

export interface CreatePaymentRequest {
  amount: number
  currency: string
  description: string
  customer: {
    name: string
    email: string
    phone?: string
  }
  metadata?: any
  expiresIn?: number
}

export interface GhostPayResponse {
  id: string
  status: string
  amount: number
  currency: string
  description: string
  payment_url: string
  pix_code?: string
  pix_qr_code?: string
  expires_at: string
  created_at: string
}

class GhostPayAPI {
  private config: GhostPayConfig

  constructor() {
    this.config = {
      apiKey: process.env.GHOSTPAY_API_KEY || "",
      apiUrl: process.env.GHOSTPAY_API_URL || "https://api.ghostpay.com.br/v1",
      webhookSecret: process.env.GHOSTPAY_WEBHOOK_SECRET || "",
    }
  }

  async createPayment(data: CreatePaymentRequest): Promise<GhostPayResponse> {
    try {
      const response = await fetch(`${this.config.apiUrl}/payments`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.config.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          success_url: `${process.env.NEXT_PUBLIC_APP_URL}?payment=success`,
          cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}?payment=cancel`,
          webhook_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/ghostpay/webhook`,
        }),
      })

      if (!response.ok) {
        throw new Error(`GhostPay API Error: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("GhostPay Create Payment Error:", error)
      throw error
    }
  }

  async getPayment(paymentId: string): Promise<GhostPayResponse> {
    try {
      const response = await fetch(`${this.config.apiUrl}/payments/${paymentId}`, {
        headers: {
          Authorization: `Bearer ${this.config.apiKey}`,
        },
      })

      if (!response.ok) {
        throw new Error(`GhostPay API Error: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("GhostPay Get Payment Error:", error)
      throw error
    }
  }

  verifyWebhookSignature(payload: string, signature: string): boolean {
    // Implementar verificação de assinatura do webhook
    // const expectedSignature = crypto.createHmac('sha256', this.config.webhookSecret).update(payload).digest('hex')
    // return signature === expectedSignature
    return true // Simplificado para demo
  }
}

export const ghostpay = new GhostPayAPI()
