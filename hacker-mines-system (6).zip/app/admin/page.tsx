"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Users,
  DollarSign,
  CreditCard,
  TrendingUp,
  Search,
  RefreshCw,
  LogOut,
  Shield,
  Crown,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  UserIcon,
  Activity,
} from "lucide-react"

interface AdminStats {
  totalUsers: number
  activeUsers: number
  lifetimeUsers: number
  totalRevenue: number
  monthlyRevenue: number
  pendingPayments: number
  conversionRate: number
  newUsersToday: number
}

interface Payment {
  id: string
  userId: string
  amount: number
  status: "pending" | "paid" | "failed" | "expired"
  method: string
  createdAt: number
  paidAt?: number
  user?: { name: string; email: string }
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("dashboard")

  // Estados do Dashboard
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [users, setUsers] = useState([])
  const [payments, setPayments] = useState([])

  // Estados de filtros e paginação
  const [userSearch, setUserSearch] = useState("")
  const [paymentFilter, setPaymentFilter] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Login
  const [loginForm, setLoginForm] = useState({ username: "", password: "" })
  const [loginError, setLoginError] = useState("")

  useEffect(() => {
    checkAuth()
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      loadDashboardData()
    }
  }, [isAuthenticated, activeTab])

  const checkAuth = async () => {
    try {
      const response = await fetch("/api/admin/stats")
      setIsAuthenticated(response.ok)
    } catch (error) {
      setIsAuthenticated(false)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoginError("")

    try {
      const response = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginForm),
      })

      if (response.ok) {
        setIsAuthenticated(true)
        loadDashboardData()
      } else {
        setLoginError("Credenciais inválidas")
      }
    } catch (error) {
      setLoginError("Erro de conexão")
    }
  }

  const handleLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" })
    setIsAuthenticated(false)
    router.push("/")
  }

  const loadDashboardData = async () => {
    setIsRefreshing(true)

    try {
      // Carregar estatísticas
      const statsResponse = await fetch("/api/admin/stats")
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData)
      }

      // Carregar usuários se aba ativa
      if (activeTab === "users") {
        const usersResponse = await fetch(`/api/admin/users?page=${currentPage}&search=${userSearch}`)
        if (usersResponse.ok) {
          const usersData = await usersResponse.json()
          setUsers(usersData.users)
        }
      }

      // Carregar pagamentos se aba ativa
      if (activeTab === "payments") {
        const paymentsResponse = await fetch(`/api/admin/payments?page=${currentPage}&status=${paymentFilter}`)
        if (paymentsResponse.ok) {
          const paymentsData = await paymentsResponse.json()
          setPayments(paymentsData.payments)
        }
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
    } finally {
      setIsRefreshing(false)
    }
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString("pt-BR")
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "paid":
        return "text-green-400 bg-green-400/10"
      case "pending":
        return "text-yellow-400 bg-yellow-400/10"
      case "failed":
        return "text-red-400 bg-red-400/10"
      case "expired":
        return "text-gray-400 bg-gray-400/10"
      default:
        return "text-gray-400 bg-gray-400/10"
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "paid":
        return <CheckCircle size={16} />
      case "pending":
        return <Clock size={16} />
      case "failed":
        return <XCircle size={16} />
      case "expired":
        return <AlertCircle size={16} />
      default:
        return <AlertCircle size={16} />
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-gray-800 rounded-2xl border border-gray-700 p-8 shadow-2xl">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-600 rounded-full mb-4">
                <Shield size={32} className="text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Admin Dashboard</h1>
              <p className="text-gray-400">HACKER MINES AI</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Usuário</label>
                <input
                  type="text"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Senha</label>
                <input
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {loginError && <div className="text-red-400 text-sm text-center">{loginError}</div>}

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-3 px-4 rounded-lg transition-colors"
              >
                Entrar
              </button>
            </form>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
                <Shield size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
                <p className="text-sm text-gray-400">HACKER MINES AI</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={loadDashboardData}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors disabled:opacity-50"
            >
              <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} />
              Atualizar
            </button>

            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors"
            >
              <LogOut size={16} />
              Sair
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-gray-800 border-b border-gray-700 px-6">
        <div className="flex space-x-8">
          {[
            { id: "dashboard", name: "Dashboard", icon: Activity },
            { id: "users", name: "Usuários", icon: Users },
            { id: "payments", name: "Pagamentos", icon: CreditCard },
          ].map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-emerald-500 text-emerald-400"
                    : "border-transparent text-gray-400 hover:text-white"
                }`}
              >
                <Icon size={18} />
                {tab.name}
              </button>
            )
          })}
        </div>
      </nav>

      {/* Content */}
      <main className="p-6">
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            {stats && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Total de Usuários</p>
                      <p className="text-2xl font-bold text-white">{stats.totalUsers}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Users size={24} className="text-white" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-sm">
                    <span className="text-green-400">+{stats.newUsersToday}</span>
                    <span className="text-gray-400">hoje</span>
                  </div>
                </div>

                <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Usuários Ativos</p>
                      <p className="text-2xl font-bold text-white">{stats.activeUsers}</p>
                    </div>
                    <div className="w-12 h-12 bg-emerald-600 rounded-lg flex items-center justify-center">
                      <Activity size={24} className="text-white" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-sm">
                    <span className="text-emerald-400">{stats.lifetimeUsers}</span>
                    <span className="text-gray-400">vitalícios</span>
                  </div>
                </div>

                <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Receita Total</p>
                      <p className="text-2xl font-bold text-white">{formatCurrency(stats.totalRevenue)}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                      <DollarSign size={24} className="text-white" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-sm">
                    <span className="text-green-400">{formatCurrency(stats.monthlyRevenue)}</span>
                    <span className="text-gray-400">este mês</span>
                  </div>
                </div>

                <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Taxa de Conversão</p>
                      <p className="text-2xl font-bold text-white">{stats.conversionRate.toFixed(1)}%</p>
                    </div>
                    <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                      <TrendingUp size={24} className="text-white" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-sm">
                    <span className="text-yellow-400">{stats.pendingPayments}</span>
                    <span className="text-gray-400">pendentes</span>
                  </div>
                </div>
              </div>
            )}

            {/* Recent Activity */}
            <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Atividade Recente</h3>
              <div className="space-y-4">
                {payments.slice(0, 5).map((payment) => (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between py-3 border-b border-gray-700 last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${getStatusColor(payment.status)}`}>
                        {getStatusIcon(payment.status)}
                      </div>
                      <div>
                        <p className="text-white font-medium">{payment.user?.name || "Usuário desconhecido"}</p>
                        <p className="text-gray-400 text-sm">{payment.user?.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{formatCurrency(payment.amount / 100)}</p>
                      <p className="text-gray-400 text-sm">{formatDate(payment.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Buscar usuários..."
                      value={userSearch}
                      onChange={(e) => setUserSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
                <button
                  onClick={loadDashboardData}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors"
                >
                  Buscar
                </button>
              </div>
            </div>

            {/* Users Table */}
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-700">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Usuário</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Status</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Cadastro</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Último Login</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-700">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-700/50">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                              <UserIcon size={20} className="text-gray-300" />
                            </div>
                            <div>
                              <p className="text-white font-medium">{user.name}</p>
                              <p className="text-gray-400 text-sm">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            {user.hasLifetimeAccess ? (
                              <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-400/10 text-yellow-400 rounded-full text-xs">
                                <Crown size={12} />
                                Vitalício
                              </span>
                            ) : user.isActive ? (
                              <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-400/10 text-emerald-400 rounded-full text-xs">
                                <CheckCircle size={12} />
                                Ativo
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-1 bg-gray-400/10 text-gray-400 rounded-full text-xs">
                                <XCircle size={12} />
                                Inativo
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-300 text-sm">{formatDate(user.createdAt)}</td>
                        <td className="px-6 py-4 text-gray-300 text-sm">
                          {user.lastLogin ? formatDate(user.lastLogin) : "Nunca"}
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-emerald-400 hover:text-emerald-300 text-sm">Ver detalhes</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "payments" && (
          <div className="space-y-6">
            {/* Filters */}
            <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
              <div className="flex items-center gap-4">
                <select
                  value={paymentFilter}
                  onChange={(e) => setPaymentFilter(e.target.value)}
                  className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-emerald-500 focus:outline-none"
                >
                  <option value="">Todos os status</option>
                  <option value="pending">Pendente</option>
                  <option value="paid">Pago</option>
                  <option value="failed">Falhou</option>
                  <option value="expired">Expirado</option>
                </select>
                <button
                  onClick={loadDashboardData}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors"
                >
                  Filtrar
                </button>
              </div>
            </div>

            {/* Payments Table */}
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-700">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">ID</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Usuário</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Valor</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Status</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Criado</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Pago</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-700">
                    {payments.map((payment) => (
                      <tr key={payment.id} className="hover:bg-gray-700/50">
                        <td className="px-6 py-4 text-gray-300 text-sm font-mono">{payment.id.slice(-8)}</td>
                        <td className="px-6 py-4">
                          <div>
                            <p className="text-white font-medium">{payment.user?.name || "N/A"}</p>
                            <p className="text-gray-400 text-sm">{payment.user?.email || "N/A"}</p>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-white font-medium">{formatCurrency(payment.amount / 100)}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getStatusColor(payment.status)}`}
                          >
                            {getStatusIcon(payment.status)}
                            {payment.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-gray-300 text-sm">{formatDate(payment.createdAt)}</td>
                        <td className="px-6 py-4 text-gray-300 text-sm">
                          {payment.paidAt ? formatDate(payment.paidAt) : "-"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
