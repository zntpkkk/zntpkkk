package mines.mines.exception;

public class RequestExcpetion extends  RuntimeException{

    public RequestExcpetion(String msg){
        super(msg);
    }
}
