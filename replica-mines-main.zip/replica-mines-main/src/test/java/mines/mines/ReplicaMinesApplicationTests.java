package mines.mines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReplicaMinesApplicationTests {

	@Test
	void contextLoads() {
	}

}
