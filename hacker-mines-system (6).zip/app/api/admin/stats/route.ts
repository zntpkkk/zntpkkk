import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { db } from "@/lib/database"

function verifyAdmin() {
  const token = cookies().get("admin-token")
  return !!token?.value
}

export async function GET() {
  if (!verifyAdmin()) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const stats = await db.getAdminStats()
    return NextResponse.json(stats)
  } catch (error) {
    return NextResponse.json({ error: "Erro ao buscar estatísticas" }, { status: 500 })
  }
}
