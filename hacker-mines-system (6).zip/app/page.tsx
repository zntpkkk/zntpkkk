"use client"

import { useState, useRef, useEffect } from "react"
import { X, Shield, CheckCircle, ArrowRight, Crown, Copy, CreditCard, LinkIcon } from "lucide-react"

// WhatsApp Icon Component
function WhatsAppIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.516" />
    </svg>
  )
}

// Instagram Icon Component
function InstagramIcon({ size = 24 }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
    </svg>
  )
}

// Telegram Icon Component
function TelegramIcon({ size = 24 }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"></path>
      <path d="m21.854 2.147-10.94 10.939"></path>
    </svg>
  )
}

// Check Icon Component
function CheckIcon({ size = 12 }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 6 9 17l-5-5"></path>
    </svg>
  )
}

// Enhanced Matrix Rain Background Component
function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.height = window.innerHeight
      canvas.width = window.innerWidth
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    const katakana =
      "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン01".split("")
    const fontSize = 16
    const columns = Math.floor(canvas.width / fontSize)
    const drops = Array(columns).fill(1)

    const draw = () => {
      ctx.fillStyle = "rgba(0, 0, 0, 0.08)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.font = `${fontSize}px 'Courier New', monospace`

      for (let i = 0; i < drops.length; i++) {
        const text = katakana[Math.floor(Math.random() * katakana.length)]
        const x = i * fontSize
        const y = drops[i] * fontSize

        const isHighlight = Math.random() > 0.95
        const isSpecial = Math.random() > 0.98

        if (isSpecial) {
          ctx.fillStyle = "#00ff41"
          ctx.shadowColor = "#00ff41"
          ctx.shadowBlur = 8
        } else if (isHighlight) {
          ctx.fillStyle = "#00d4aa"
          ctx.shadowColor = "#00d4aa"
          ctx.shadowBlur = 4
        } else {
          ctx.fillStyle = "#1a4d3a"
          ctx.shadowColor = "#1a4d3a"
          ctx.shadowBlur = 2
        }

        ctx.fillText(text, x, y)
        ctx.shadowBlur = 0

        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0
        }
        drops[i]++
      }

      requestAnimationFrame(draw)
    }

    draw()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0"
      style={{ background: "linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%)" }}
    />
  )
}

// Device Fingerprinting
function generateDeviceId() {
  const canvas = document.createElement("canvas")
  const ctx = canvas.getContext("2d")
  if (ctx) {
    ctx.textBaseline = "top"
    ctx.font = "14px Arial"
    ctx.fillText("Device fingerprint", 2, 2)
  }

  const fingerprint = [
    navigator.userAgent,
    navigator.language,
    screen.width + "x" + screen.height,
    new Date().getTimezoneOffset(),
    canvas.toDataURL(),
    navigator.hardwareConcurrency || 0,
    navigator.deviceMemory || 0,
  ].join("|")

  // Simple hash function
  let hash = 0
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }

  return Math.abs(hash).toString(36)
}

// User Management System
interface UserData {
  id: string
  name: string
  email: string
  phone: string
  startDate: number
  expirationDate: number
  isActive: boolean
  deviceId: string
  createdAt: number
  hasLifetimeAccess?: boolean
}

function useUserSystem() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [isNewUser, setIsNewUser] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const [isExpired, setIsExpired] = useState(false)

  useEffect(() => {
    const deviceId = generateDeviceId()
    const savedUser = localStorage.getItem("hackerMinesUser")

    if (savedUser) {
      try {
        const user: UserData = JSON.parse(savedUser)
        const now = Date.now()

        if (user.deviceId === deviceId) {
          if (user.hasLifetimeAccess) {
            // Usuário tem acesso vitalício
            setUserData(user)
            setTimeLeft(Number.POSITIVE_INFINITY)
          } else if (user.expirationDate > now) {
            // Usuário ainda tem tempo restante
            setUserData(user)
            setTimeLeft(Math.floor((user.expirationDate - now) / 1000))
          } else {
            // Usuário expirado
            setUserData(user)
            setIsExpired(true)
            setTimeLeft(0)
          }
        } else {
          // Different device, treat as new user
          setIsNewUser(true)
        }
      } catch (error) {
        setIsNewUser(true)
      }
    } else {
      setIsNewUser(true)
    }
  }, [])

  useEffect(() => {
    if (userData && !isExpired && timeLeft > 0 && timeLeft !== Number.POSITIVE_INFINITY) {
      const interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsExpired(true)
            return 0
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [userData, isExpired, timeLeft])

  const createUser = (name: string, email: string, phone: string) => {
    const deviceId = generateDeviceId()
    const now = Date.now()
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000 // 30 days

    const newUser: UserData = {
      id: `user_${now}_${Math.random().toString(36).substr(2, 9)}`,
      name,
      email,
      phone,
      startDate: now,
      expirationDate: now + thirtyDaysInMs,
      isActive: true,
      deviceId,
      createdAt: now,
      hasLifetimeAccess: false,
    }

    localStorage.setItem("hackerMinesUser", JSON.stringify(newUser))
    setUserData(newUser)
    setTimeLeft(Math.floor(thirtyDaysInMs / 1000))
    setIsNewUser(false)
    setIsExpired(false)
  }

  const upgradeToLifetime = () => {
    if (userData) {
      const updatedUser = {
        ...userData,
        hasLifetimeAccess: true,
      }
      localStorage.setItem("hackerMinesUser", JSON.stringify(updatedUser))
      setUserData(updatedUser)
      setTimeLeft(Number.POSITIVE_INFINITY)
      setIsExpired(false)
    }
  }

  const formatTime = (seconds: number) => {
    if (seconds === Number.POSITIVE_INFINITY) return "∞ VITALÍCIO"

    const days = Math.floor(seconds / (24 * 60 * 60))
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60))
    const minutes = Math.floor((seconds % (60 * 60)) / 60)
    const secs = seconds % 60

    if (days > 0) {
      return `${days}d ${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const getDaysLeft = () => {
    if (timeLeft === Number.POSITIVE_INFINITY) return Number.POSITIVE_INFINITY
    return Math.ceil(timeLeft / (24 * 60 * 60))
  }

  const getProgressPercentage = () => {
    if (!userData || userData.hasLifetimeAccess) return 100
    const totalTime = userData.expirationDate - userData.startDate
    const elapsed = Date.now() - userData.startDate
    return Math.max(0, Math.min(100, ((totalTime - elapsed) / totalTime) * 100))
  }

  return {
    userData,
    isNewUser,
    timeLeft,
    isExpired,
    createUser,
    upgradeToLifetime,
    formatTime,
    getDaysLeft,
    getProgressPercentage,
    hasActiveAccess:
      userData && (!isExpired || userData.hasLifetimeAccess) && (timeLeft > 0 || userData.hasLifetimeAccess),
  }
}

// GhostPay Integration Hook - REAL INTEGRATION
function useGhostPay() {
  const [isLoading, setIsLoading] = useState(false)
  const [paymentData, setPaymentData] = useState<any>(null)
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "pending" | "success" | "failed">("idle")

  const generatePaymentLink = async (userData: UserData | null) => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/ghostpay/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userData?.id,
          amount: 12700, // R$ 127,00 em centavos
          description: "HACKER MINES AI - Acesso Vitalício",
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const result = await response.json()

      if (result.success) {
        setPaymentData(result.payment)
        setPaymentStatus("pending")
        return result.payment
      } else {
        throw new Error(result.error || "Erro desconhecido")
      }
    } catch (error) {
      console.error("Erro ao gerar pagamento:", error)
      setPaymentStatus("failed")
      return null
    } finally {
      setIsLoading(false)
    }
  }

  const checkPaymentStatus = async (paymentId: string) => {
    try {
      const response = await fetch(`/api/ghostpay/status/${paymentId}`)

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const result = await response.json()

      if (result.success) {
        setPaymentStatus(result.status === "paid" ? "success" : "pending")
        return result.status
      }

      return "failed"
    } catch (error) {
      console.error("Erro ao verificar pagamento:", error)
      return "failed"
    }
  }

  return {
    generatePaymentLink,
    checkPaymentStatus,
    paymentData,
    paymentStatus,
    isLoading,
    setPaymentStatus,
  }
}

// Payment Modal Component - REAL INTEGRATION
function PaymentModal({
  isOpen,
  onClose,
  userData,
  onPaymentSuccess,
}: {
  isOpen: boolean
  onClose: () => void
  userData: UserData | null
  onPaymentSuccess: () => void
}) {
  const { generatePaymentLink, checkPaymentStatus, paymentData, paymentStatus, isLoading } = useGhostPay()
  const [selectedMethod, setSelectedMethod] = useState<"pix" | "card" | "link">("pix")
  const [timeLeft, setTimeLeft] = useState(30 * 60) // 30 minutos
  const [isCheckingStatus, setIsCheckingStatus] = useState(false)
  const [copyFeedback, setCopyFeedback] = useState("")

  useEffect(() => {
    if (isOpen && !paymentData && userData) {
      generatePaymentLink(userData)
    }
  }, [isOpen, userData])

  useEffect(() => {
    if (paymentData && paymentStatus === "pending") {
      const interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval)
            return 0
          }
          return prev - 1
        })
      }, 1000)

      // Verificar status a cada 15 segundos
      const statusInterval = setInterval(() => {
        if (paymentData?.id) {
          checkPaymentStatus(paymentData.id)
        }
      }, 15000)

      return () => {
        clearInterval(interval)
        clearInterval(statusInterval)
      }
    }
  }, [paymentData, paymentStatus])

  useEffect(() => {
    if (paymentStatus === "success") {
      onPaymentSuccess()
    }
  }, [paymentStatus, onPaymentSuccess])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopyFeedback(`${type} copiado!`)
      setTimeout(() => setCopyFeedback(""), 2000)
    } catch (error) {
      setCopyFeedback("Erro ao copiar")
      setTimeout(() => setCopyFeedback(""), 2000)
    }
  }

  const handleCheckStatus = async () => {
    if (!paymentData?.id) return

    setIsCheckingStatus(true)
    const status = await checkPaymentStatus(paymentData.id)
    setIsCheckingStatus(false)

    if (status === "paid") {
      setTimeout(() => {
        onPaymentSuccess()
      }, 1000)
    }
  }

  if (!isOpen) return null

  if (paymentStatus === "success") {
    return (
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/95 backdrop-blur-sm p-4">
        <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border border-emerald-500/30 p-6 text-white shadow-2xl">
          <div className="mb-6 text-center">
            <div className="mb-4 flex items-center justify-center">
              <div className="rounded-full p-4 bg-gradient-to-br from-emerald-500 to-cyan-500 shadow-lg animate-bounce">
                <CheckCircle size={32} className="text-white" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2 bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              🎉 Pagamento Aprovado!
            </h2>
            <p className="text-sm text-gray-400">Seu acesso vitalício foi ativado!</p>
          </div>

          <div className="mb-6 rounded-xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 p-5">
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Produto:</span>
                <span className="text-white font-medium">HACKER MINES AI</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Valor:</span>
                <span className="text-emerald-400 font-bold">R$ 127,00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Status:</span>
                <span className="text-emerald-400 font-bold">✅ APROVADO</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Acesso:</span>
                <span className="text-emerald-400 font-bold">🔓 VITALÍCIO</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              onClose()
              window.location.reload()
            }}
            className="w-full rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 py-4 px-6 font-bold text-white transition-all shadow-lg border border-emerald-500/50"
          >
            Começar a Usar Agora
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/95 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border border-gray-700 p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full bg-gray-800 p-2 transition-all hover:bg-gray-700 border border-gray-600 z-10"
        >
          <X size={16} className="text-gray-300" />
        </button>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="mb-6 flex items-center justify-center">
              <div className="relative">
                <div className="h-16 w-16 rounded-full border-4 border-gray-700"></div>
                <div className="absolute inset-0 h-16 w-16 rounded-full border-4 border-transparent border-t-emerald-500 animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Crown size={20} className="text-emerald-500" />
                </div>
              </div>
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Gerando Pagamento...</h3>
            <p className="text-sm text-gray-400">Conectando com GhostPay</p>
          </div>
        ) : (
          <>
            <div className="mb-6 text-center">
              <div className="mb-4 flex items-center justify-center">
                <div className="rounded-full p-3 bg-gradient-to-br from-green-600 to-emerald-600 shadow-lg">
                  <Crown size={24} className="text-white" />
                </div>
              </div>
              <h2 className="text-xl font-bold text-white mb-2 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                Adquirir Acesso Vitalício
              </h2>
              <p className="text-sm text-gray-400">Pagamento processado pela GhostPay</p>
              {timeLeft > 0 && <div className="mt-2 text-xs text-yellow-400">⏰ Expira em: {formatTime(timeLeft)}</div>}
            </div>

            {/* Copy Feedback */}
            {copyFeedback && (
              <div className="mb-4 text-center">
                <div className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs bg-emerald-600 text-white">
                  <CheckCircle size={12} />
                  {copyFeedback}
                </div>
              </div>
            )}

            {/* Payment Method Selector */}
            <div className="mb-6">
              <div className="grid grid-cols-3 gap-2 p-1 bg-gray-800 rounded-lg">
                {[
                  { id: "pix", name: "PIX", icon: "🏦" },
                  { id: "card", name: "Cartão", icon: "💳" },
                  { id: "link", name: "Link", icon: "🔗" },
                ].map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setSelectedMethod(method.id as any)}
                    className={`py-2 px-3 rounded-md text-sm font-medium transition-all ${
                      selectedMethod === method.id
                        ? "bg-emerald-600 text-white"
                        : "text-gray-400 hover:text-white hover:bg-gray-700"
                    }`}
                  >
                    <span className="block text-lg mb-1">{method.icon}</span>
                    {method.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Content */}
            {selectedMethod === "pix" && paymentData && (
              <div className="space-y-4">
                <div className="rounded-xl bg-gray-800/50 border border-gray-700 p-4">
                  <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-2">
                    🏦 Pagamento via PIX
                  </h3>

                  {/* QR Code */}
                  {paymentData.pixQrCode && (
                    <div className="mb-4 text-center">
                      <div className="inline-block p-4 bg-white rounded-lg">
                        <img
                          src={paymentData.pixQrCode || "/placeholder.svg"}
                          alt="QR Code PIX"
                          className="w-32 h-32"
                        />
                      </div>
                      <p className="text-xs text-gray-400 mt-2">Escaneie com seu app do banco</p>
                    </div>
                  )}

                  {/* PIX Code */}
                  {paymentData.pixCode && (
                    <div className="mb-4">
                      <label className="block text-xs text-gray-400 mb-2">Código PIX (Copia e Cola):</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={paymentData.pixCode}
                          readOnly
                          className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-xs text-white font-mono"
                        />
                        <button
                          onClick={() => copyToClipboard(paymentData.pixCode, "Código PIX")}
                          className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 rounded text-xs font-medium transition-all flex items-center gap-1"
                        >
                          <Copy size={12} />
                          Copiar
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="text-xs text-gray-400 space-y-1">
                    <p>• Abra seu app do banco</p>
                    <p>• Escolha PIX Copia e Cola</p>
                    <p>• Cole o código acima</p>
                    <p>
                      • Confirme o pagamento de <strong className="text-emerald-400">R$ 127,00</strong>
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleCheckStatus}
                  disabled={isCheckingStatus}
                  className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 py-3 px-6 font-medium text-white transition-all shadow-lg border border-blue-500/50 disabled:opacity-50"
                >
                  {isCheckingStatus ? (
                    <span className="flex items-center justify-center gap-2">
                      <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      Verificando...
                    </span>
                  ) : (
                    "Já Paguei - Verificar Status"
                  )}
                </button>
              </div>
            )}

            {selectedMethod === "card" && paymentData && (
              <div className="space-y-4">
                <div className="rounded-xl bg-gray-800/50 border border-gray-700 p-4">
                  <h3 className="text-sm font-bold text-blue-400 mb-3 flex items-center gap-2">
                    💳 Pagamento com Cartão
                  </h3>

                  <div className="space-y-3 text-sm text-gray-300">
                    <div className="flex items-center gap-2">
                      <CheckCircle size={16} className="text-emerald-500" />
                      <span>Cartão de Crédito ou Débito</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle size={16} className="text-emerald-500" />
                      <span>Parcelamento em até 12x</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle size={16} className="text-emerald-500" />
                      <span>Aprovação instantânea</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle size={16} className="text-emerald-500" />
                      <span>Ambiente 100% seguro</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => window.open(paymentData.paymentUrl, "_blank")}
                  className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 py-4 px-6 font-bold text-white transition-all shadow-lg border border-blue-500/50 group"
                >
                  <span className="flex items-center justify-center gap-3">
                    <CreditCard size={18} />
                    <span>Pagar com Cartão</span>
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </span>
                </button>
              </div>
            )}

            {selectedMethod === "link" && paymentData && (
              <div className="space-y-4">
                <div className="rounded-xl bg-gray-800/50 border border-gray-700 p-4">
                  <h3 className="text-sm font-bold text-purple-400 mb-3 flex items-center gap-2">
                    🔗 Link de Pagamento
                  </h3>

                  <div className="mb-4">
                    <label className="block text-xs text-gray-400 mb-2">Link para compartilhar:</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={paymentData.paymentUrl}
                        readOnly
                        className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-xs text-white"
                      />
                      <button
                        onClick={() => copyToClipboard(paymentData.paymentUrl, "Link")}
                        className="px-3 py-2 bg-purple-600 hover:bg-purple-500 rounded text-xs font-medium transition-all flex items-center gap-1"
                      >
                        <Copy size={12} />
                        Copiar
                      </button>
                    </div>
                  </div>

                  <div className="text-xs text-gray-400 space-y-1">
                    <p>• Compartilhe este link</p>
                    <p>• Acesse de qualquer dispositivo</p>
                    <p>• Múltiplas formas de pagamento</p>
                    <p>• PIX, Cartão, Boleto disponíveis</p>
                  </div>
                </div>

                <button
                  onClick={() => window.open(paymentData.paymentUrl, "_blank")}
                  className="w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 py-4 px-6 font-bold text-white transition-all shadow-lg border border-purple-500/50 group"
                >
                  <span className="flex items-center justify-center gap-3">
                    <LinkIcon size={18} />
                    <span>Abrir Link de Pagamento</span>
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </span>
                </button>
              </div>
            )}

            {/* Payment Info */}
            <div className="mt-6 rounded-xl bg-green-500/10 border border-green-500/30 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Shield size={16} className="text-green-400" />
                <h3 className="text-sm font-bold text-green-400">Pagamento Seguro</h3>
              </div>
              <div className="space-y-1 text-xs text-gray-300">
                <p>✅ Processado pela GhostPay</p>
                <p>✅ Dados criptografados SSL</p>
                <p>✅ Ativação automática</p>
                <p>✅ Suporte 24/7</p>
              </div>
            </div>

            {/* Price Summary */}
            <div className="mt-4 rounded-xl bg-gray-800/50 border border-gray-700 p-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Total a pagar:</span>
                <span className="text-2xl font-bold text-emerald-400">R$ 127,00</span>
              </div>
              <div className="text-xs text-gray-500 mt-1">Pagamento único • Acesso vitalício • Sem mensalidades</div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

// Continue with the rest of the components...
// [Rest of the components remain the same as in the previous implementation]

// Main App Component
export default function HackerMinesApp() {
  const [showAnalysis, setShowAnalysis] = useState(false)
  const [showNoEntryModal, setShowNoEntryModal] = useState(false)
  const [showWelcomeModal, setShowWelcomeModal] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [redirectUrl, setRedirectUrl] = useState("")
  const [showPaymentModal, setShowPaymentModal] = useState(false)

  // User system hook
  const {
    userData,
    isNewUser,
    timeLeft,
    isExpired,
    createUser,
    upgradeToLifetime,
    formatTime,
    getDaysLeft,
    getProgressPercentage,
    hasActiveAccess,
  } = useUserSystem()

  // Show welcome modal for new users
  useEffect(() => {
    if (isNewUser) {
      setShowWelcomeModal(true)
    }
  }, [isNewUser])

  const handleUserRegistration = (name: string, email: string, phone: string) => {
    createUser(name, email, phone)
    setShowWelcomeModal(false)
    setShowSuccessModal(true)
  }

  const handleStartAnalysis = (url: string) => {
    setRedirectUrl(url)
    setShowAnalysis(true)
  }

  const handlePaymentSuccess = () => {
    upgradeToLifetime()
    setShowPaymentModal(false)
  }

  return (
    <div className="relative h-screen w-full overflow-hidden">
      <MatrixRain />

      {/* Payment Modal - REAL INTEGRATION */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        userData={userData}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Rest of the app remains the same... */}
    </div>
  )
}
