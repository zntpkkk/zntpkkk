import { type NextRequest, NextResponse } from "next/server"
import { ghostpay } from "@/lib/ghostpay"
import { db } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { userId, amount = 12700, description = "HACKER MINES AI - Acesso Vitalício" } = await request.json()

    // Buscar usuário
    const user = await db.getUserById(userId)
    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Criar pagamento na GhostPay
    const ghostpayPayment = await ghostpay.createPayment({
      amount,
      currency: "BRL",
      description,
      customer: {
        name: user.name,
        email: user.email,
        phone: user.phone,
      },
      metadata: {
        userId: user.id,
        product: "hacker_mines_lifetime",
      },
      expiresIn: 30 * 60, // 30 minutos
    })

    // Salvar pagamento no banco
    const payment = await db.createPayment({
      id: `pay_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId: user.id,
      ghostpayId: ghostpayPayment.id,
      amount,
      currency: "BRL",
      status: "pending",
      method: "pix",
      description,
      pixCode: ghostpayPayment.pix_code,
      pixQrCode: ghostpayPayment.pix_qr_code,
      paymentUrl: ghostpayPayment.payment_url,
      expiresAt: new Date(ghostpayPayment.expires_at).getTime(),
      createdAt: Date.now(),
    })

    return NextResponse.json({
      success: true,
      payment: {
        id: payment.id,
        ghostpayId: ghostpayPayment.id,
        amount: payment.amount,
        status: payment.status,
        pixCode: payment.pixCode,
        pixQrCode: payment.pixQrCode,
        paymentUrl: payment.paymentUrl,
        expiresAt: payment.expiresAt,
      },
    })
  } catch (error) {
    console.error("Create Payment Error:", error)
    return NextResponse.json({ error: "Erro ao criar pagamento" }, { status: 500 })
  }
}
