import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { db } from "@/lib/database"

function verifyAdmin() {
  const token = cookies().get("admin-token")
  return !!token?.value
}

export async function GET(request: NextRequest) {
  if (!verifyAdmin()) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const status = searchParams.get("status") || ""

    let payments = await db.getAllPayments()

    // Filtrar por status
    if (status) {
      payments = payments.filter((payment) => payment.status === status)
    }

    // Ordenar por data de criação (mais recentes primeiro)
    payments.sort((a, b) => b.createdAt - a.createdAt)

    // Paginação
    const total = payments.length
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedPayments = payments.slice(startIndex, endIndex)

    // Buscar dados dos usuários
    const paymentsWithUsers = await Promise.all(
      paginatedPayments.map(async (payment) => {
        const user = await db.getUserById(payment.userId)
        return {
          ...payment,
          user: user ? { name: user.name, email: user.email } : null,
        }
      }),
    )

    return NextResponse.json({
      payments: paymentsWithUsers,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    return NextResponse.json({ error: "Erro ao buscar pagamentos" }, { status: 500 })
  }
}
