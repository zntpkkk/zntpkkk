// Database Schema e Funções
export interface User {
  id: string
  name: string
  email: string
  phone: string
  deviceId: string
  startDate: number
  expirationDate: number
  hasLifetimeAccess: boolean
  isActive: boolean
  createdAt: number
  lastLogin?: number
  ipAddress?: string
  userAgent?: string
}

export interface Payment {
  id: string
  userId: string
  ghostpayId: string
  amount: number
  currency: string
  status: "pending" | "paid" | "failed" | "expired"
  method: "pix" | "card" | "boleto"
  description: string
  pixCode?: string
  pixQrCode?: string
  paymentUrl?: string
  expiresAt: number
  paidAt?: number
  createdAt: number
  metadata?: any
}

export interface AdminStats {
  totalUsers: number
  activeUsers: number
  lifetimeUsers: number
  totalRevenue: number
  monthlyRevenue: number
  pendingPayments: number
  conversionRate: number
  newUsersToday: number
}

// Simulação de banco de dados (em produção, usar PostgreSQL/MongoDB)
class Database {
  private users: Map<string, User> = new Map()
  private payments: Map<string, Payment> = new Map()

  // Usuários
  async createUser(user: User): Promise<User> {
    this.users.set(user.id, user)
    return user
  }

  async getUserById(id: string): Promise<User | null> {
    return this.users.get(id) || null
  }

  async getUserByEmail(email: string): Promise<User | null> {
    for (const user of this.users.values()) {
      if (user.email === email) return user
    }
    return null
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    const user = this.users.get(id)
    if (!user) return null

    const updatedUser = { ...user, ...updates }
    this.users.set(id, updatedUser)
    return updatedUser
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values())
  }

  // Pagamentos
  async createPayment(payment: Payment): Promise<Payment> {
    this.payments.set(payment.id, payment)
    return payment
  }

  async getPaymentById(id: string): Promise<Payment | null> {
    return this.payments.get(id) || null
  }

  async getPaymentByGhostpayId(ghostpayId: string): Promise<Payment | null> {
    for (const payment of this.payments.values()) {
      if (payment.ghostpayId === ghostpayId) return payment
    }
    return null
  }

  async updatePayment(id: string, updates: Partial<Payment>): Promise<Payment | null> {
    const payment = this.payments.get(id)
    if (!payment) return null

    const updatedPayment = { ...payment, ...updates }
    this.payments.set(id, updatedPayment)
    return updatedPayment
  }

  async getAllPayments(): Promise<Payment[]> {
    return Array.from(this.payments.values())
  }

  async getPaymentsByUserId(userId: string): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter((p) => p.userId === userId)
  }

  // Estatísticas
  async getAdminStats(): Promise<AdminStats> {
    const users = Array.from(this.users.values())
    const payments = Array.from(this.payments.values())

    const now = Date.now()
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime()
    const dayStart = new Date().setHours(0, 0, 0, 0)

    const totalUsers = users.length
    const activeUsers = users.filter((u) => u.isActive && (u.hasLifetimeAccess || u.expirationDate > now)).length
    const lifetimeUsers = users.filter((u) => u.hasLifetimeAccess).length
    const totalRevenue = payments.filter((p) => p.status === "paid").reduce((sum, p) => sum + p.amount, 0) / 100
    const monthlyRevenue =
      payments
        .filter((p) => p.status === "paid" && p.paidAt && p.paidAt >= monthStart)
        .reduce((sum, p) => sum + p.amount, 0) / 100
    const pendingPayments = payments.filter((p) => p.status === "pending").length
    const newUsersToday = users.filter((u) => u.createdAt >= dayStart).length
    const conversionRate = totalUsers > 0 ? (lifetimeUsers / totalUsers) * 100 : 0

    return {
      totalUsers,
      activeUsers,
      lifetimeUsers,
      totalRevenue,
      monthlyRevenue,
      pendingPayments,
      conversionRate,
      newUsersToday,
    }
  }
}

export const db = new Database()
