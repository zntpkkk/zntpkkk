import { type NextRequest, NextResponse } from "next/server"
import { ghostpay } from "@/lib/ghostpay"
import { db } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const paymentId = params.id

    // Buscar pagamento no banco
    const payment = await db.getPaymentById(paymentId)
    if (!payment) {
      return NextResponse.json({ error: "Payment not found" }, { status: 404 })
    }

    // Verificar status na GhostPay
    const ghostpayPayment = await ghostpay.getPayment(payment.ghostpayId)

    // Atualizar status local se necessário
    if (ghostpayPayment.status !== payment.status) {
      await db.updatePayment(payment.id, {
        status: ghostpayPayment.status as any,
        paidAt: ghostpayPayment.status === "paid" ? Date.now() : undefined,
      })

      // Se foi pago, ativar acesso vitalício
      if (ghostpayPayment.status === "paid") {
        await db.updateUser(payment.userId, {
          hasLifetimeAccess: true,
          isActive: true,
        })
      }
    }

    return NextResponse.json({
      success: true,
      status: ghostpayPayment.status,
      payment: {
        id: payment.id,
        status: ghostpayPayment.status,
        amount: payment.amount,
        paidAt: payment.paidAt,
      },
    })
  } catch (error) {
    console.error("Check Status Error:", error)
    return NextResponse.json({ error: "Erro ao verificar status" }, { status: 500 })
  }
}
