import { type NextRequest, NextResponse } from "next/server"
import { ghostpay } from "@/lib/ghostpay"
import { db } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("x-ghostpay-signature") || ""

    // Verificar assinatura do webhook
    if (!ghostpay.verifyWebhookSignature(body, signature)) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
    }

    const webhookData = JSON.parse(body)
    const { id: ghostpayId, status, paid_at } = webhookData

    // Buscar pagamento
    const payment = await db.getPaymentByGhostpayId(ghostpayId)
    if (!payment) {
      return NextResponse.json({ error: "Payment not found" }, { status: 404 })
    }

    // Atualizar status do pagamento
    await db.updatePayment(payment.id, {
      status: status === "paid" ? "paid" : status,
      paidAt: paid_at ? new Date(paid_at).getTime() : undefined,
    })

    // Se pagamento foi aprovado, ativar acesso vitalício
    if (status === "paid") {
      await db.updateUser(payment.userId, {
        hasLifetimeAccess: true,
        isActive: true,
      })

      console.log(`✅ Pagamento aprovado! Usuário ${payment.userId} agora tem acesso vitalício`)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook Error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
