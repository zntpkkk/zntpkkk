import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

const ADMIN_CREDENTIALS = {
  username: process.env.ADMIN_USERNAME || "admin",
  password: process.env.ADMIN_PASSWORD || "hacker123",
}

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      // Criar token de sessão (em produção, usar JWT)
      const token = Buffer.from(`${username}:${Date.now()}`).toString("base64")

      cookies().set("admin-token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 horas
      })

      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: "Credenciais inválidas" }, { status: 401 })
  } catch (error) {
    return NextResponse.json({ error: "Erro no servidor" }, { status: 500 })
  }
}

export async function DELETE() {
  cookies().delete("admin-token")
  return NextResponse.json({ success: true })
}
